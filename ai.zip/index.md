# Home - Seisund ja diagnoos IG v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://fhir.ee/dgn/ImplementationGuide/ee.fhir.dgn | *Version*:0.1.0 |
| Draft as of 2026-05-18 | *Computable Name*:EETISIGDIAGNOSIS |

### Intro

Seisund ja diagnoos juurutusjuhend.

#### Source code

This IG source code is available in [GitHub](https://github.com/TEHIK-EE/ig-ee-diagnosis).

